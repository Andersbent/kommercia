/**
 * Performs a Google search via Serper.dev. See https://serper.dev/ for API docs.
 * You must set the SERPER_API_KEY environment variable in your `.env.local`.
 *
 * @param query Search query
 * @param num   Number of results to return (default: 10)
 */
export async function searchSerper(query: string, num = 10) {
  const apiKey = process.env.SERPER_API_KEY;
  if (!apiKey) {
    throw new Error('Missing SERPER_API_KEY');
  }
  const res = await fetch('https://google.serper.dev/search', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-API-KEY': apiKey
    },
    body: JSON.stringify({ q: query, num })
  });
  if (!res.ok) {
    throw new Error(`Serper API failed: ${res.statusText}`);
  }
  const data = await res.json();
  return data;
}