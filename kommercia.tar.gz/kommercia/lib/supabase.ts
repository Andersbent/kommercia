import { createClient, type SupabaseClient } from '@supabase/supabase-js';

/**
 * Returns a supabase client configured for browser usage (anon key).
 * Use this in client components. It relies on the anon key, so RLS must
 * enforce that users only see their own data.
 */
export function getSupabaseBrowser(): SupabaseClient {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
  return createClient(url, anonKey);
}

/**
 * Returns a supabase client configured for server usage with the service role key.
 * Only use this on the server (e.g. API routes or server components) because the
 * service role key bypasses RLS. Always ensure you manually filter by user id.
 */
export function getSupabaseService(): SupabaseClient {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
  return createClient(url, serviceKey);
}