import { OpenAI } from 'openai';

// Initialize OpenAI client lazily to avoid unnecessary instantiation
let openai: OpenAI | null = null;
function getOpenAI() {
  if (!openai) {
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      throw new Error('Missing OPENAI_API_KEY');
    }
    openai = new OpenAI({ apiKey });
  }
  return openai;
}

/**
 * Uses GPT‑4 to generate a list of qualified leads based on a custom prompt.
 * This function is called from the API route `/api/newLeads`.
 *
 * @param prompt A text prompt describing the ideal lead criteria.
 * @param count  Number of leads to generate (default: 10)
 */
export async function generateLeads(prompt: string, count = 10) {
  const client = getOpenAI();
  const completion = await client.chat.completions.create({
    model: 'gpt-4o',
    messages: [
      {
        role: 'system',
        content:
          'You are a helpful AI that generates B2B sales leads. You receive a description of an ideal customer profile and must return a JSON array where each element contains a company name, a contact person, their role, a short description, and optionally email and phone if available. Do not include any text outside of the JSON array.'
      },
      {
        role: 'user',
        content: `Generate ${count} qualified leads based on the following description: ${prompt}`
      }
    ],
    temperature: 0.6,
    max_tokens: 1000,
    response_format: { type: 'json_object' }
  });

  // The API returns a JSON object; we parse and return its leads property if present.
  try {
    const json = JSON.parse(completion.choices[0].message.content ?? '{}');
    return json.leads ?? json;
  } catch (err) {
    console.error('Failed to parse GPT response', err);
    return [];
  }
}