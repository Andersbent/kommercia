"use client";

import { SessionProvider } from 'next-auth/react';
import type { ReactNode } from 'react';

/**
 * Wraps children with NextAuth SessionProvider. This component must be a client
 * component because SessionProvider relies on React context.
 */
export default function Providers({ children }: { children: ReactNode }) {
  return <SessionProvider>{children}</SessionProvider>;
}